# DBMS_Municipal_Corp
Project for creating a Database Management System for Municipal Corporation's complaint and grievances section
